<?php
require_once 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$pageTitle = 'Sign In - iReport';
include 'includes/header.php';
include 'includes/navbar.php';
?>
        <!-- Main Content -->
        <div class="container mt-5">
            <div class="row">
                <!-- Left sidebar -->
                <div class="col-md-3">
                    <!-- Sidebar content if needed -->
                </div>

                <!-- Middle content (spans 2 columns) -->
                <div class="col-md-6">
                    <!-- Add your page-specific content here -->
                        <div class="card shadow-sm">
                            <div class="card-body p-4">
                                <h1 class="text-center mb-4">Sign In</h1>
                                <!-- Email Sign In Form -->
                                <form class="needs-validation" novalidate>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email address</label>
                                        <input type="email" class="form-control" id="email" required>
                                        <div class="invalid-feedback">
                                            Please enter a valid email address.
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" required>
                                        <div class="invalid-feedback">
                                            Please enter your password.
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3 form-check">
                                        <input type="checkbox" class="form-check-input" id="rememberMe">
                                        <label class="form-check-label" for="rememberMe">Remember me</label>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Sign In</button>
                                    </div>
                                    
                                    <div class="text-center mt-3">
                                        <a href="forgot-password.html" class="text-decoration-none">Forgot password?</a>
                                    </div>
                                </form>
                                
                                <!-- Divider -->
                                <div class="d-flex align-items-center my-4">
                                    <hr class="flex-grow-1">
                                    <span class="px-3 text-muted">OR</span>
                                    <hr class="flex-grow-1">
                                </div>
                                
                                <!-- Social Media Sign In -->
                                <div class="d-grid gap-2">
                                    <!-- Google Sign In -->
                                    <button class="btn btn-outline-dark" type="button">
                                        <img src="img/google-icon.png" alt="Google" style="width: 20px; margin-right: 8px;">
                                        Sign in with Google
                                    </button>
                                    
                                    <!-- Meta/Facebook Sign In -->
                                    <button class="btn btn-outline-primary" type="button">
                                        <i class="bi bi-facebook me-2"></i>
                                        Sign in with Facebook
                                    </button>
                                    
                                    <!-- X/Twitter Sign In -->
                                    <button class="btn btn-outline-dark" type="button">
                                        <i class="bi bi-twitter-x me-2"></i>
                                        Sign in with X
                                    </button>
                                </div>
                                
                                <!-- Sign Up Link -->
                                <div class="text-center mt-4">
                                    <p class="mb-0">Don't have an account? 
                                        <a href="signup.html" class="text-decoration-none">Sign up</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right sidebar -->
                <div class="col-md-3">
                    <!-- Sidebar content if needed -->
                </div>
            </div>
        </div>

<?php
$additionalScripts = '<script src="js/signin.js></script>';
include 'includes/footer.php';
?>