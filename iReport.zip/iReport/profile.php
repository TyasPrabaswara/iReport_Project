<?php
$pageTitle = 'Profile - iReport';
include 'includes/header.php';
include 'includes/navbar.php';
?>

        <div class="container mt-5">
            <div class="row">
                <!-- Left sidebar -->
                <div class="col-md-3">
                    <!-- Sidebar content if needed -->
                </div>

                <!-- Middle content (spans 2 columns) -->
                <div class="col-md-6">
                    <h1>About</h1>
                    <!-- Add your page-specific content here -->
                </div>

                <!-- Right sidebar -->
                <div class="col-md-3">
                    <!-- Sidebar content if needed -->
                </div>
            </div>
        </div>

<?php include 'includes/footer.php'; ?>