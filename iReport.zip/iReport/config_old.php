<?php
session_start();

// Site configuration
define('SITE_NAME', 'iReport');
define('SITE_URL', 'http://localhost/your-project'); // Update with your URL

// Database configuration (if needed)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ireport');

// Helper functions
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirectTo($page) {
    header("Location: $page.php");
    exit();
}
?>