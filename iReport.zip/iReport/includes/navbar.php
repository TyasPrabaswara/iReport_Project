<?php
// Temporary test variable - switch between true/false to test different states
$isTestLoggedIn = true; // Change this to true to test logged-in state
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo SITE_URL; ?>/home.php">iReport</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if ($isTestLoggedIn): ?>
                    <!-- Logged in navigation -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'dashboard') ? 'active' : ''; ?>" 
                           href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'report') ? 'active' : ''; ?>" 
                           href="report.php">New Report</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'my-reports') ? 'active' : ''; ?>" 
                           href="my-reports.php">My Reports</a>
                    </li>
                <?php else: ?>
                    <!-- Guest navigation -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/contact.php">Contact</a>
                    </li>
                <?php endif; ?>
            </ul>
            
            <!-- User Profile Dropdown -->
            <div class="dropdown">
                <button class="btn dropdown-toggle d-flex align-items-center" type="button" id="userDropdown" data-bs-toggle="dropdown">
                    <?php if ($isTestLoggedIn): ?>
                        <img src="<?php echo SITE_URL; ?>/img/default-avatar.png" alt="User" class="user-avatar me-2">
                        <span>Test User</span>
                    <?php else: ?>
                        <i class="fas fa-user me-2"></i> <!-- You'll need FontAwesome for this icon -->
                        <span>Guest</span>
                    <?php endif; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <?php if ($isTestLoggedIn): ?>
                        <!-- Logged in dropdown items -->
                        <li><a class="dropdown-item text-white" href="profile.php">Profile</a></li>
                        <li><a class="dropdown-item text-white" href="settings.php">Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-white" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <!-- Guest dropdown items -->
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/signIn.php">Sign In</a></li>
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>