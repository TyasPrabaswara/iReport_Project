<?php
//Temporary test variable, true = logged in, false = guest mode
$isTestLoggedIn = false;
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo SITE_URL; ?>/dashboard.php">iReport</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo ($currentPage === 'dashboard') ? 'active' : ''; ?>" 
                       href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo ($currentPage === 'report') ? 'active' : ''; ?>" 
                       href="report.php">New Report</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo ($currentPage === 'my-reports') ? 'active' : ''; ?>" 
                       href="my-reports.php">My Reports</a>
                </li>
            </ul>
            
            <!-- User Profile Dropdown -->
            <div class="dropdown">
                <button class="btn dropdown-toggle d-flex align-items-center" type="button" id="userDropdown" data-bs-toggle="dropdown">
                    <img src="img/default-avatar.png" alt="User" class="user-avatar me-2">
                    <span><?php echo htmlspecialchars($_SESSION['username'] ?? 'Guest'); ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                    <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>