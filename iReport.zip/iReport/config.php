<?php
// Define your site URL - adjust this to match your setup
define('SITE_URL', 'http://localhost');

// Add any other configuration constants you need
define('SITE_NAME', 'iReport');
?>