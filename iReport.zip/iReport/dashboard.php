<?php
$pageTitle = 'Dashboard - iReport';
include 'includes/header.php';
include 'includes/navbar.php';
?>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Welcome Section -->
        <div class="row mb-4">
            <div class="col">
                <h2>Welcome back, Username!</h2>
                <p>Here's an overview of your reporting activity</p>
            </div>
        </div>

        <!-- Stats Overview -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="dashboard-stat">
                    <h3>Total Reports</h3>
                    <h2 class="text-primary">12</h2>
                    <p class="text-muted">All time reports submitted</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-stat">
                    <h3>Pending</h3>
                    <h2 class="text-warning">3</h2>
                    <p class="text-muted">Reports awaiting response</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-stat">
                    <h3>Resolved</h3>
                    <h2 class="text-success">9</h2>
                    <p class="text-muted">Successfully resolved reports</p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <h3>Quick Actions</h3>
                <div class="d-grid gap-2 d-md-flex">
                    <a href="report.html" class="btn btn-primary">New Report</a>
                    <a href="my-reports.html" class="btn btn-outline-primary">View My Reports</a>
                </div>
            </div>
        </div>

        <!-- Recent Reports -->
        <div class="row">
            <div class="col-12">
                <h3>Recent Reports</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>2024-03-15</td>
                                <td>Transportation</td>
                                <td>Bus Route 101</td>
                                <td><span class="badge bg-warning">Pending</span></td>
                                <td><a href="#" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                            <tr>
                                <td>2024-03-14</td>
                                <td>Facility</td>
                                <td>Central Station</td>
                                <td><span class="badge bg-success">Resolved</span></td>
                                <td><a href="#" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>