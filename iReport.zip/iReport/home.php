<?php
$pageTitle = 'Home - iReport';
include 'includes/header.php';
include 'includes/navbar.php';
?>

<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
         <!-- Main Content with 4-column grid -->
    <div class="container-fluid p-0">
        <div class="position-relative">
            <!-- Text and button overlay -->
            <div class="position-absolute top-50 start-50 translate-middle text-center text-white">
                <h1 class="display-4 fw-bold">Report incidents or broken facilities easily</h1>
                <p class="lead">Reports will be directly sent to DISHUB, making the process easier</p>
                <a href="<?php echo SITE_URL; ?>/signIn.php" class="btn btn-primary btn-lg">Sign In</a>
            </div>
            
            <!-- Full-width image -->
            <img src="<?php echo SITE_URL; ?>/img/transjogja.jpg" class="img-fluid w-100" alt="Hero image" 
                 style="height: 600px; object-fit: cover;">
        </div>

        <div class="row my-5">
            <!-- Left empty column -->
            <div class="col-md-3">
                <!-- Sidebar content if needed -->
            </div>

            <!-- Middle content (spans 2 columns) -->
            <div class="col-md-6">
                <h1>Main Content</h1>
                <p>This content spans the two middle columns of the grid.</p>
                <!-- Add your content here -->
            </div>

            <!-- Right empty column -->
            <div class="col-md-3">
                <!-- Sidebar content if needed -->
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
